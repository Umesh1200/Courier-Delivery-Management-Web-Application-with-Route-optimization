import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RoleBasedNavigation from '../../components/ui/RoleBasedNavigation';

import QuickActionPanel from '../../components/ui/QuickActionPanel';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import PackageDetailsForm from './components/PackageDetailsForm';
import AddressForm from './components/AddressForm';
import SchedulingForm from './components/SchedulingForm';
import SpecialInstructionsForm from './components/SpecialInstructionsForm';
import PricingCalculator from './components/PricingCalculator';
import ProgressIndicator from './components/ProgressIndicator';

const CreateBooking = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSaveConfirmation, setShowSaveConfirmation] = useState(false);

  const steps = [
    { id: 'package', label: 'Package Details', icon: 'Package' },
    { id: 'address', label: 'Addresses', icon: 'MapPin' },
    { id: 'schedule', label: 'Schedule', icon: 'Calendar' },
    { id: 'instructions', label: 'Instructions', icon: 'FileText' }
  ];

  const [formData, setFormData] = useState({
    category: '',
    size: '',
    weight: '',
    value: '',
    description: '',
    length: '',
    width: '',
    height: '',
    pickupAddress: '',
    pickupCity: '',
    pickupState: '',
    pickupZip: '',
    pickupPhone: '',
    pickupContactName: '',
    deliveryAddress: '',
    deliveryCity: '',
    deliveryState: '',
    deliveryZip: '',
    deliveryPhone: '',
    deliveryContactName: '',
    serviceType: '',
    scheduledDate: '',
    scheduledTime: '',
    specialInstructions: '',
    signatureRequired: false,
    photoProof: false,
    callBeforeDelivery: false,
    fragileHandling: false,
    insurance: false
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    const savedDraft = localStorage.getItem('bookingDraft');
    if (savedDraft) {
      try {
        const parsedDraft = JSON.parse(savedDraft);
        setFormData(parsedDraft);
      } catch (error) {
        console.error('Error loading draft:', error);
      }
    }
  }, []);

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 0:
        if (!formData?.category) newErrors.category = 'Please select a package category';
        if (!formData?.size) newErrors.size = 'Please select a package size';
        if (!formData?.weight) newErrors.weight = 'Please enter package weight';
        if (!formData?.description) newErrors.description = 'Please provide a package description';
        break;
      case 1:
        if (!formData?.pickupAddress) newErrors.pickupAddress = 'Pickup address is required';
        if (!formData?.pickupCity) newErrors.pickupCity = 'Pickup city is required';
        if (!formData?.pickupState) newErrors.pickupState = 'Pickup state is required';
        if (!formData?.pickupZip) newErrors.pickupZip = 'Pickup ZIP code is required';
        if (!formData?.pickupPhone) newErrors.pickupPhone = 'Pickup phone is required';
        if (!formData?.pickupContactName) newErrors.pickupContactName = 'Pickup contact name is required';
        if (!formData?.deliveryAddress) newErrors.deliveryAddress = 'Delivery address is required';
        if (!formData?.deliveryCity) newErrors.deliveryCity = 'Delivery city is required';
        if (!formData?.deliveryState) newErrors.deliveryState = 'Delivery state is required';
        if (!formData?.deliveryZip) newErrors.deliveryZip = 'Delivery ZIP code is required';
        if (!formData?.deliveryPhone) newErrors.deliveryPhone = 'Delivery phone is required';
        if (!formData?.deliveryContactName) newErrors.deliveryContactName = 'Delivery contact name is required';
        break;
      case 2:
        if (!formData?.serviceType) newErrors.serviceType = 'Please select a service type';
        if (formData?.serviceType === 'scheduled') {
          if (!formData?.scheduledDate) newErrors.scheduledDate = 'Please select a delivery date';
          if (!formData?.scheduledTime) newErrors.scheduledTime = 'Please select a time slot';
        }
        break;
      case 3:
        break;
      default:
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep < steps?.length - 1) {
        setCurrentStep(prev => prev + 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSaveDraft = () => {
    setIsSaving(true);
    localStorage.setItem('bookingDraft', JSON.stringify(formData));
    setTimeout(() => {
      setIsSaving(false);
      setShowSaveConfirmation(true);
      setTimeout(() => setShowSaveConfirmation(false), 3000);
    }, 1000);
  };

  const handleSubmit = () => {
    if (validateStep(currentStep)) {
      setIsSubmitting(true);
      setTimeout(() => {
        localStorage.removeItem('bookingDraft');
        navigate('/user-dashboard', { 
          state: { 
            message: 'Booking created successfully! Tracking ID: CF2026001',
            bookingData: formData 
          } 
        });
      }, 2000);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return <PackageDetailsForm formData={formData} errors={errors} onChange={handleChange} />;
      case 1:
        return <AddressForm formData={formData} errors={errors} onChange={handleChange} />;
      case 2:
        return <SchedulingForm formData={formData} errors={errors} onChange={handleChange} />;
      case 3:
        return <SpecialInstructionsForm formData={formData} errors={errors} onChange={handleChange} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedNavigation userRole="customer" userName="John Doe" notificationCount={3} />
      <div className="pt-[60px]">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-8 lg:py-12">
          <div className="mb-6 md:mb-8">
            <button
              onClick={() => navigate('/user-dashboard')}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-4"
            >
              <Icon name="ArrowLeft" size={16} />
              Back to Dashboard
            </button>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-2">Create New Booking</h1>
            <p className="text-sm md:text-base text-muted-foreground">Fill in the details to schedule your delivery</p>
          </div>

          <ProgressIndicator currentStep={currentStep} steps={steps} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
            <div className="lg:col-span-2 space-y-6 md:space-y-8">
              {renderStepContent()}

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 md:gap-4 bg-card rounded-xl p-4 md:p-6 shadow-elevation-md">
                <Button
                  variant="outline"
                  onClick={handleSaveDraft}
                  loading={isSaving}
                  iconName="Save"
                  iconPosition="left"
                  className="w-full sm:w-auto"
                >
                  Save Draft
                </Button>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {currentStep > 0 && (
                    <Button
                      variant="secondary"
                      onClick={handlePrevious}
                      iconName="ChevronLeft"
                      iconPosition="left"
                      className="flex-1 sm:flex-none"
                    >
                      Previous
                    </Button>
                  )}
                  
                  {currentStep < steps?.length - 1 ? (
                    <Button
                      variant="default"
                      onClick={handleNext}
                      iconName="ChevronRight"
                      iconPosition="right"
                      className="flex-1 sm:flex-none"
                    >
                      Next Step
                    </Button>
                  ) : (
                    <Button
                      variant="default"
                      onClick={handleSubmit}
                      loading={isSubmitting}
                      iconName="CheckCircle"
                      iconPosition="left"
                      className="flex-1 sm:flex-none"
                    >
                      Submit Booking
                    </Button>
                  )}
                </div>
              </div>

              {showSaveConfirmation && (
                <div className="fixed bottom-6 right-6 bg-success text-success-foreground px-4 md:px-6 py-3 md:py-4 rounded-lg shadow-elevation-xl flex items-center gap-3 animate-slide-up z-50">
                  <Icon name="CheckCircle" size={20} />
                  <span className="text-sm md:text-base font-medium">Draft saved successfully!</span>
                </div>
              )}
            </div>

            <div className="lg:col-span-1">
              <PricingCalculator formData={formData} />
            </div>
          </div>
        </div>
      </div>
      <QuickActionPanel userRole="customer" />
    </div>
  );
};

export default CreateBooking;