import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const PackageDetailsForm = ({ formData, errors, onChange }) => {
  const packageCategories = [
    { value: 'documents', label: 'Documents', description: 'Papers, letters, contracts' },
    { value: 'electronics', label: 'Electronics', description: 'Phones, laptops, gadgets' },
    { value: 'clothing', label: 'Clothing & Textiles', description: 'Apparel, fabrics' },
    { value: 'food', label: 'Food & Beverages', description: 'Perishable items' },
    { value: 'fragile', label: 'Fragile Items', description: 'Glass, ceramics, artwork' },
    { value: 'other', label: 'Other', description: 'General items' }
  ];

  const packageSizes = [
    { value: 'small', label: 'Small', description: 'Up to 5 lbs, fits in envelope' },
    { value: 'medium', label: 'Medium', description: '5-20 lbs, shoebox size' },
    { value: 'large', label: 'Large', description: '20-50 lbs, suitcase size' },
    { value: 'xlarge', label: 'Extra Large', description: '50+ lbs, requires special handling' }
  ];

  return (
    <div className="bg-card rounded-xl p-4 md:p-6 lg:p-8 shadow-elevation-md">
      <div className="flex items-center gap-3 mb-4 md:mb-6">
        <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Package" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h2 className="text-lg md:text-xl lg:text-2xl font-semibold text-foreground">Package Details</h2>
          <p className="text-xs md:text-sm text-muted-foreground">Provide information about your package</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <Select
          label="Package Category"
          description="Select the type of items you're sending"
          options={packageCategories}
          value={formData?.category}
          onChange={(value) => onChange('category', value)}
          error={errors?.category}
          required
          searchable
          placeholder="Choose category"
        />

        <Select
          label="Package Size"
          description="Approximate size and weight range"
          options={packageSizes}
          value={formData?.size}
          onChange={(value) => onChange('size', value)}
          error={errors?.size}
          required
          placeholder="Select size"
        />

        <Input
          label="Weight (lbs)"
          type="number"
          placeholder="Enter weight"
          value={formData?.weight}
          onChange={(e) => onChange('weight', e?.target?.value)}
          error={errors?.weight}
          description="Accurate weight helps with pricing"
          required
          min="0.1"
          step="0.1"
        />

        <Input
          label="Declared Value (USD)"
          type="number"
          placeholder="Enter value"
          value={formData?.value}
          onChange={(e) => onChange('value', e?.target?.value)}
          error={errors?.value}
          description="For insurance purposes"
          min="0"
          step="0.01"
        />

        <div className="md:col-span-2">
          <Input
            label="Package Description"
            type="text"
            placeholder="Brief description of contents"
            value={formData?.description}
            onChange={(e) => onChange('description', e?.target?.value)}
            error={errors?.description}
            description="Help us handle your package properly"
            required
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-2">
            Dimensions (Optional)
          </label>
          <div className="grid grid-cols-3 gap-3">
            <Input
              type="number"
              placeholder="Length (in)"
              value={formData?.length}
              onChange={(e) => onChange('length', e?.target?.value)}
              min="0"
              step="0.1"
            />
            <Input
              type="number"
              placeholder="Width (in)"
              value={formData?.width}
              onChange={(e) => onChange('width', e?.target?.value)}
              min="0"
              step="0.1"
            />
            <Input
              type="number"
              placeholder="Height (in)"
              value={formData?.height}
              onChange={(e) => onChange('height', e?.target?.value)}
              min="0"
              step="0.1"
            />
          </div>
        </div>
      </div>
      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-muted rounded-lg">
        <div className="flex items-start gap-3">
          <Icon name="Info" size={18} color="var(--color-primary)" className="flex-shrink-0 mt-0.5" />
          <div className="text-xs md:text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Packaging Tips:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Use sturdy boxes for fragile items</li>
              <li>Seal packages securely with tape</li>
              <li>Include padding for delicate contents</li>
              <li>Label fragile items clearly</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PackageDetailsForm;