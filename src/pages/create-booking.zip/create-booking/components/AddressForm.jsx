import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const AddressForm = ({ formData, errors, onChange }) => {
  const [showPickupMap, setShowPickupMap] = useState(false);
  const [showDeliveryMap, setShowDeliveryMap] = useState(false);

  const handleAddressAutocomplete = (type, value) => {
    onChange(type, value);
    
    // Mock autocomplete suggestions
    if (value?.length > 3) {
      const suggestions = [
        '123 Main Street, New York, NY 10001',
        '456 Oak Avenue, Brooklyn, NY 11201',
        '789 Pine Road, Queens, NY 11354'
      ];
      // In real implementation, this would trigger autocomplete dropdown
    }
  };

  return (
    <div className="bg-card rounded-xl p-4 md:p-6 lg:p-8 shadow-elevation-md">
      <div className="flex items-center gap-3 mb-4 md:mb-6">
        <div className="w-10 h-10 md:w-12 md:h-12 bg-accent/10 rounded-lg flex items-center justify-center">
          <Icon name="MapPin" size={20} color="var(--color-accent)" />
        </div>
        <div>
          <h2 className="text-lg md:text-xl lg:text-2xl font-semibold text-foreground">Pickup & Delivery Addresses</h2>
          <p className="text-xs md:text-sm text-muted-foreground">Enter complete address details</p>
        </div>
      </div>
      <div className="space-y-6 md:space-y-8">
        {/* Pickup Address Section */}
        <div className="border border-border rounded-lg p-4 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base md:text-lg font-semibold text-foreground flex items-center gap-2">
              <Icon name="PackageCheck" size={18} color="var(--color-success)" />
              Pickup Address
            </h3>
            <Button
              variant="ghost"
              size="sm"
              iconName="Map"
              iconPosition="left"
              onClick={() => setShowPickupMap(!showPickupMap)}
            >
              {showPickupMap ? 'Hide' : 'Show'} Map
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <Input
              label="Street Address"
              type="text"
              placeholder="Enter pickup address"
              value={formData?.pickupAddress}
              onChange={(e) => handleAddressAutocomplete('pickupAddress', e?.target?.value)}
              error={errors?.pickupAddress}
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="City"
                type="text"
                placeholder="City"
                value={formData?.pickupCity}
                onChange={(e) => onChange('pickupCity', e?.target?.value)}
                error={errors?.pickupCity}
                required
              />
              <Input
                label="State"
                type="text"
                placeholder="State"
                value={formData?.pickupState}
                onChange={(e) => onChange('pickupState', e?.target?.value)}
                error={errors?.pickupState}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="ZIP Code"
                type="text"
                placeholder="ZIP Code"
                value={formData?.pickupZip}
                onChange={(e) => onChange('pickupZip', e?.target?.value)}
                error={errors?.pickupZip}
                required
                maxLength="10"
              />
              <Input
                label="Contact Phone"
                type="tel"
                placeholder="(555) 123-4567"
                value={formData?.pickupPhone}
                onChange={(e) => onChange('pickupPhone', e?.target?.value)}
                error={errors?.pickupPhone}
                required
              />
            </div>

            <Input
              label="Contact Name"
              type="text"
              placeholder="Name of person at pickup location"
              value={formData?.pickupContactName}
              onChange={(e) => onChange('pickupContactName', e?.target?.value)}
              error={errors?.pickupContactName}
              required
            />

            {showPickupMap && (
              <div className="w-full h-48 md:h-64 rounded-lg overflow-hidden border border-border">
                <iframe
                  width="100%"
                  height="100%"
                  loading="lazy"
                  title="Pickup Location Map"
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://www.google.com/maps?q=40.7128,-74.0060&z=14&output=embed"
                />
              </div>
            )}
          </div>
        </div>

        {/* Delivery Address Section */}
        <div className="border border-border rounded-lg p-4 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base md:text-lg font-semibold text-foreground flex items-center gap-2">
              <Icon name="MapPinned" size={18} color="var(--color-accent)" />
              Delivery Address
            </h3>
            <Button
              variant="ghost"
              size="sm"
              iconName="Map"
              iconPosition="left"
              onClick={() => setShowDeliveryMap(!showDeliveryMap)}
            >
              {showDeliveryMap ? 'Hide' : 'Show'} Map
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <Input
              label="Street Address"
              type="text"
              placeholder="Enter delivery address"
              value={formData?.deliveryAddress}
              onChange={(e) => handleAddressAutocomplete('deliveryAddress', e?.target?.value)}
              error={errors?.deliveryAddress}
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="City"
                type="text"
                placeholder="City"
                value={formData?.deliveryCity}
                onChange={(e) => onChange('deliveryCity', e?.target?.value)}
                error={errors?.deliveryCity}
                required
              />
              <Input
                label="State"
                type="text"
                placeholder="State"
                value={formData?.deliveryState}
                onChange={(e) => onChange('deliveryState', e?.target?.value)}
                error={errors?.deliveryState}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="ZIP Code"
                type="text"
                placeholder="ZIP Code"
                value={formData?.deliveryZip}
                onChange={(e) => onChange('deliveryZip', e?.target?.value)}
                error={errors?.deliveryZip}
                required
                maxLength="10"
              />
              <Input
                label="Contact Phone"
                type="tel"
                placeholder="(555) 123-4567"
                value={formData?.deliveryPhone}
                onChange={(e) => onChange('deliveryPhone', e?.target?.value)}
                error={errors?.deliveryPhone}
                required
              />
            </div>

            <Input
              label="Contact Name"
              type="text"
              placeholder="Name of person at delivery location"
              value={formData?.deliveryContactName}
              onChange={(e) => onChange('deliveryContactName', e?.target?.value)}
              error={errors?.deliveryContactName}
              required
            />

            {showDeliveryMap && (
              <div className="w-full h-48 md:h-64 rounded-lg overflow-hidden border border-border">
                <iframe
                  width="100%"
                  height="100%"
                  loading="lazy"
                  title="Delivery Location Map"
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://www.google.com/maps?q=40.7589,-73.9851&z=14&output=embed"
                />
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-muted rounded-lg">
        <div className="flex items-start gap-3">
          <Icon name="AlertCircle" size={18} color="var(--color-warning)" className="flex-shrink-0 mt-0.5" />
          <div className="text-xs md:text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Address Requirements:</p>
            <p>Ensure addresses are complete and accurate. Incorrect addresses may result in delivery delays or additional charges.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddressForm;